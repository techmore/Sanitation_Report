from pdf import PdfFileReader, PdfFileWriter
import warnings
__all__ = ["pdf"]
warnings.warn( "shouldn't use python-pypdf anymore! Now use python-pypdf2.", DeprecationWarning)
